#!/bin/bash
rkt gc
